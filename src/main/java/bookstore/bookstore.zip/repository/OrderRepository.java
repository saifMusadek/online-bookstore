package bookstore.repository;

import bookstore.domain.Order;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class OrderRepository {

    @Autowired
    private SessionFactory sessionFactory;

    public void save(Order order) {
        sessionFactory.getCurrentSession().save(order);
    }

    public void delete(Order order) {
        sessionFactory.getCurrentSession().delete(order);
    }

    public List<Order> getAll() {
        return sessionFactory.getCurrentSession().createQuery("from Order", Order.class).list();
    }

    public Order getById(Integer id) {
        return sessionFactory.getCurrentSession().get(Order.class, id);
    }

    public boolean update(Order order) {
        Session session = sessionFactory.getCurrentSession();
        session.update(order);
        return true;
    }
}
