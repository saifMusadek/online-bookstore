package bookstore.controller;

import bookstore.domain.Author;
import bookstore.services.AuthorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/authors")
public class AuthorController {

    @Autowired
    private AuthorService authorService;

    @PostMapping
    public void createAuthor(@RequestBody Author author) {
        authorService.save(author);
    }

    @GetMapping
    public List<Author> getAllAuthors() {
        return authorService.getAll();
    }

    @GetMapping("/{id}")
    public Author getAuthorById(@PathVariable Integer id) {
        return authorService.getById(id);
    }

    @PutMapping("/{id}")
    public void updateAuthor(@PathVariable Integer id, @RequestBody Author author) {
        Author existingAuthor = authorService.getById(id);
        if (existingAuthor != null) {
            author.setId(id);
            authorService.update(author);
        }
    }

    @DeleteMapping("/{id}")
    public void deleteAuthor(@PathVariable Integer id) {
        Author author = authorService.getById(id);
        if (author != null) {
            authorService.delete(author);
        }
    }
}
