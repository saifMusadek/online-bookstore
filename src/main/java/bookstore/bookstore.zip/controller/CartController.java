package bookstore.controller;

import bookstore.domain.Cart;
import bookstore.services.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/carts")
public class CartController {

    @Autowired
    private CartService cartService;

    @PostMapping
    public void createCart(@RequestBody Cart cart) {
        cartService.save(cart);
    }

    @GetMapping
    public List<Cart> getAllCarts() {
        return cartService.getAll();
    }

    @GetMapping("/{id}")
    public Cart getCartById(@PathVariable Integer id) {
        return cartService.getById(id);
    }

    @PutMapping("/{id}")
    public void updateCart(@PathVariable Integer id, @RequestBody Cart cart) {
        Cart existingCart = cartService.getById(id);
        if (existingCart != null) {
            cart.setId(id);
            cartService.update(cart);
        }
    }

    @DeleteMapping("/{id}")
    public void deleteCart(@PathVariable Integer id) {
        Cart cart = cartService.getById(id);
        if (cart != null) {
            cartService.delete(cart);
        }
    }
}
