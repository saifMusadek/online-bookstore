package bookstore.controller;

import bookstore.domain.OrderItem;
import bookstore.services.OrderItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/order-items")
public class OrderItemController {

    @Autowired
    private OrderItemService orderItemService;

    @PostMapping
    public void createOrderItem(@RequestBody OrderItem orderItem) {
        orderItemService.save(orderItem);
    }

    @GetMapping
    public List<OrderItem> getAllOrderItems() {
        return orderItemService.getAll();
    }

    @GetMapping("/{id}")
    public OrderItem getOrderItemById(@PathVariable Integer id) {
        return orderItemService.getById(id);
    }

    @PutMapping("/{id}")
    public void updateOrderItem(@PathVariable Integer id, @RequestBody OrderItem orderItem) {
        OrderItem existingOrderItem = orderItemService.getById(id);
        if (existingOrderItem != null) {
            orderItem.setId(id);
            orderItemService.update(orderItem);
        }
    }

    @DeleteMapping("/{id}")
    public void deleteOrderItem(@PathVariable Integer id) {
        OrderItem orderItem = orderItemService.getById(id);
        if (orderItem != null) {
            orderItemService.delete(orderItem);
        }
    }
}
