package bookstore.controller;

import bookstore.domain.User;
import bookstore.domain.UserRole;
import bookstore.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.sql.SQLException;
import java.util.List;

@Controller
public class UserController {
    @Autowired
    private UserService userService;

    @RequestMapping(value="/index", method= RequestMethod.GET)
    public String getOrderPage(Model model) {
        List<User> users = userService.getAll();
        model.addAttribute("userList", users);
        return "index";
    }

    @RequestMapping(value = "/signup", method=RequestMethod.GET)
    public String showPage() {
        return "/signup";
    }

    @RequestMapping(value="/signup", method=RequestMethod.POST)
    public String handleRegister(@ModelAttribute User user, Model model) {
    user.setRole(1);


        this.userService.save(user);
        return "redirect:/index";
    }


    @RequestMapping(value="delete/{id}", method=RequestMethod.GET)
    public String deleteItem(@PathVariable Integer id) {
        User user = userService.getById(id);
        userService.delete(user);
        return "redirect:/index";
    }

    @RequestMapping("/update")
    public String update(@Valid @ModelAttribute("customer") User user, BindingResult bindingResult) throws SQLException {
        if (bindingResult.hasErrors()) {
            return "customer/edit";
        }
        userService.update(user);
        return "redirect:/customers/list";
    }


}
