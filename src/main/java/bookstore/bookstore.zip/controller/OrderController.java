package bookstore.controller;

import bookstore.domain.Order;
import bookstore.services.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping
    public void createOrder(@RequestBody Order order) {
        orderService.save(order);
    }

    @GetMapping
    public List<Order> getAllOrders() {
        return orderService.getAll();
    }

    @GetMapping("/{id}")
    public Order getOrderById(@PathVariable Integer id) {
        return orderService.getById(id);
    }

    @PutMapping("/{id}")
    public void updateOrder(@PathVariable Integer id, @RequestBody Order order) {
        Order existingOrder = orderService.getById(id);
        if (existingOrder != null) {
            order.setId(id);
            orderService.update(order);
        }
    }

    @DeleteMapping("/{id}")
    public void deleteOrder(@PathVariable Integer id) {
        Order order = orderService.getById(id);
        if (order != null) {
            orderService.delete(order);
        }
    }
}
