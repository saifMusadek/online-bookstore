package bookstore.controller;

import bookstore.domain.Category;
import bookstore.services.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@RestController
@RequestMapping("/categories")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    @PostMapping
    public void createCategory(@RequestBody Category category) {
        categoryService.save(category);
    }

    @GetMapping
    public List<Category> getAllCategories() {
        return categoryService.getAll();
    }

    @GetMapping("/{id}")
    public Category getCategoryById(@PathVariable Integer id) {
        return categoryService.getById(id);
    }

    @PutMapping("/{id}")
    public void updateCategory(@PathVariable Integer id, @RequestBody Category category) {
        Category existingCategory = categoryService.getById(id);
        if (existingCategory != null) {
            category.setId(id);
            categoryService.update(category);
        }
    }

    @DeleteMapping("/{id}")
    public void deleteCategory(@PathVariable Integer id) {
        Category category = categoryService.getById(id);
        if (category != null) {
            categoryService.delete(category);
        }
    }



}
