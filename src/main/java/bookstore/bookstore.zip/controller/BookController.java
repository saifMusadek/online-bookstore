package bookstore.controller;

import bookstore.domain.Book;
import bookstore.services.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @PostMapping
    public void createBook(@RequestBody Book book) {
        bookService.save(book);
    }

    @GetMapping
    public List<Book> getAllBooks() {
        return bookService.getAll();
    }

    @GetMapping("/{id}")
    public Book getBookById(@PathVariable Integer id) {
        return bookService.getById(id);
    }

    @PutMapping("/{id}")
    public void updateBook(@PathVariable Integer id, @RequestBody Book book) {
        Book existingBook = bookService.getById(id);
        if (existingBook != null) {
            book.setId(id);
            bookService.update(book);
        }
    }

    @DeleteMapping("/{id}")
    public void deleteBook(@PathVariable Integer id) {
        Book book = bookService.getById(id);
        if (book != null) {
            bookService.delete(book);
        }
    }
}
