package bookstore.controller;

import bookstore.domain.CartItem;
import bookstore.services.CartItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cartItems")
public class CartItemController {

    @Autowired
    private CartItemService cartItemService;

    @PostMapping
    public void createCartItem(@RequestBody CartItem cartItem) {
        cartItemService.save(cartItem);
    }

    @GetMapping
    public List<CartItem> getAllCartItems() {
        return cartItemService.getAll();
    }

    @GetMapping("/{id}")
    public CartItem getCartItemById(@PathVariable Integer id) {
        return cartItemService.getById(id);
    }

    @PutMapping("/{id}")
    public void updateCartItem(@PathVariable Integer id, @RequestBody CartItem cartItem) {
        CartItem existingCartItem = cartItemService.getById(id);
        if (existingCartItem != null) {
            cartItem.setId(id);
            cartItemService.update(cartItem);
        }
    }

    @DeleteMapping("/{id}")
    public void deleteCartItem(@PathVariable Integer id) {
        CartItem cartItem = cartItemService.getById(id);
        if (cartItem != null) {
            cartItemService.delete(cartItem);
        }
    }
}
